from flask import Flask, jsonify, request, send_from_directory
import os
import pickle
import lightgbm as lgb

app = Flask(__name__, static_folder='static')
model = lgb.Booster(model_file='modelg1g2.txt')

@app.route('/', methods=['GET'])
def index():
    return send_from_directory('static', 'index.html')

@app.route('/predict', methods=['POST'])
def predict():
    # This function will handle the prediction logic
    data = request.json
    # TODO: Process data and make prediction
    print(data)
    # input_data = [data['feature1'], data['feature2'], ...]
    q1r = int(data['question1'])
    q2r = int(data['question2'])
    q3r = int(data['question3'])
    q4r = int(data['question4'])
    q5r = int(data['question5'])
    q6r = int(data['question6'])
    q7r = data['question7']
    q8r = data['question8']
    q9r = int(data['question9'])
    q10r = int(data['question10'])
    q11r = int(data['question11'])


    input_data = [[q1r, q2r, q3r, q4r, q5r, q6r, q7r, q8r, q9r, q10r]]

    # prediction = model.predict(input_data) # This code is bugging out - we have a working model, the problem arose when we tried to import the model here and use it to make predictions
    prediction = 'Student needs extra help' if q1r < 14 else 'Student is on track to succeed in your class'
    recommendation = 'Schedule tutoring with this student' if q1r < 14 else ''
    result = {'prediction': prediction, 'recommendation': recommendation}
    return jsonify(result)

if __name__ == '__main__':
    app.run(debug=True)